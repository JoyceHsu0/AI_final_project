package com.example.cart.product

class product (var img_d: Int, var name_d:String)