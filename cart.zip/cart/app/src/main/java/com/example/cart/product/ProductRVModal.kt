package com.example.cart.product

class ProductRVModal {
    var ID : String? = null
    var p_name: String? = null
    var content: String? = null
    var price: String? = null
    var picture: String? = null
}