package com.example.cart.ai

data class Message(val message: String, val id: String, val time: String)
//message = message that the user send
//id = who send/receive the message
//time = when the message will be send
