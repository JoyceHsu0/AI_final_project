package com.example.cart.cart

class CartRVModal {
    var p_id : String? = null
    var p_num: String? = null
    var p_name: String? = null
    var p_price: String? = null
    var p_img: String? = null
}